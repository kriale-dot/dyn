# SYN — Etapa 111.4
## Banco limpo de produção — IP Filadélfia

O arquivo `syn.sql` enviado ao servidor NÃO deve ser importado em produção.

A inspeção mostrou que ele contém:

- programações `[TESTE]`;
- notificações de teste;
- usuários `@teste.syn.local`;
- `admin@syn.local`;
- `maria@syn.local`;
- hashes de senhas do ambiente de desenvolvimento.

Este pacote usa as migrations consolidadas do SYN e remove o cenário de
validação/desenvolvimento.

## O que será criado

- estrutura completa do banco;
- papéis fixos do sistema:
  - Administrador
  - Organizador
  - Membro
- permissões e tabelas das etapas posteriores;
- registro institucional singleton da igreja.

NÃO serão criados:

- usuários de desenvolvimento;
- programações de teste;
- escalas de teste;
- notificações de teste.

## Nome institucional inicial

O seed usa:

`Igreja Filadélfia`

Esse nome poderá ser alterado depois pela tela Dados da Igreja.

## Instalação no servidor

Envie esta pasta para, por exemplo:

`/root/syn-db-producao`

Depois:

```bash
cd /root/syn-db-producao
chmod +x instalar_banco.sh
./instalar_banco.sh
```

Digite a senha do usuário:

`syn_ipfiladelfia_app`

quando solicitado.

A senha não é colocada no histórico do shell.

## Resultado esperado

No final:

- todas as tabelas aparecem;
- a tabela `usuarios` contém ZERO registros;
- a tabela `papeis` contém 3 registros;
- a tabela `igreja` contém 1 registro.

O primeiro Administrador será criado em uma etapa separada e segura.

## Importante

Não execute `syn.sql` no banco de produção.

Depois que a instalação limpa for validada, o `syn.sql` de desenvolvimento
pode ser removido do diretório da API.

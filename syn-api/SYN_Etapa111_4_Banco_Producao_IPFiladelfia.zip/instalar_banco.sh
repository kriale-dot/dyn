#!/usr/bin/env bash
set -euo pipefail

DB_NAME="syn_ipfiladelfia"
DB_USER="syn_ipfiladelfia_app"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MIGRATIONS_DIR="$SCRIPT_DIR/migrations"

if ! command -v mariadb >/dev/null 2>&1; then
    echo "Erro: comando mariadb não encontrado."
    exit 1
fi

read -r -s -p "Senha de ${DB_USER}: " DB_PASS
echo

export MYSQL_PWD="$DB_PASS"

cleanup() {
    unset MYSQL_PWD
}
trap cleanup EXIT

FILES=(
    "01_schema_base_ipfiladelfia.sql"
    "02_seed_producao_ipfiladelfia.sql"
    "03_permissoes_organizador.sql"
    "04_permissoes_especiais.sql"
    "05_recuperacao_senha.sql"
    "06_notificacoes.sql"
    "07_eventos_programacao.sql"
    "08_auditoria.sql"
    "09_modo_publico.sql"
    "10_cadastro_com_aprovacao.sql"
    "11_rate_limit.sql"
    "12_confirmacao_email_cadastro.sql"
    "13_revogacao_sessoes.sql"
    "14_alteracao_segura_email.sql"
    "15_expiracao_cadastros_email.sql"
    "16_eventos_seguranca_conta.sql"
)

echo "Instalando banco limpo do SYN em ${DB_NAME}..."

for file in "${FILES[@]}"; do
    echo "-> $file"
    mariadb \
        --host=localhost \
        --user="$DB_USER" \
        "$DB_NAME" \
        < "$MIGRATIONS_DIR/$file"
done

echo
echo "Banco instalado com sucesso."
echo
echo "Tabelas:"
mariadb \
    --host=localhost \
    --user="$DB_USER" \
    "$DB_NAME" \
    -e "SHOW TABLES;"

echo
echo "Usuários atualmente cadastrados:"
mariadb \
    --host=localhost \
    --user="$DB_USER" \
    "$DB_NAME" \
    -e "SELECT id,nome,email,status FROM usuarios ORDER BY id;"

echo
echo "O resultado esperado agora é ZERO usuários."
echo "O primeiro Administrador será criado na próxima etapa."

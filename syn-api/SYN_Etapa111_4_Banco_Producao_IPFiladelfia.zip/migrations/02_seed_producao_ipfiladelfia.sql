-- ============================================================
-- SYN - Seed limpo de PRODUÇÃO
-- Instalação: ipfiladelfia
-- ============================================================

USE syn_ipfiladelfia;

START TRANSACTION;

-- Cada instalação SYN representa uma única igreja.
-- Este registro é necessário porque a aplicação atualiza
-- o singleton existente, em vez de criar a igreja no primeiro uso.
INSERT INTO igreja (
    id,
    singleton,
    nome
)
VALUES (
    1,
    1,
    'Igreja Filadélfia'
)
ON DUPLICATE KEY UPDATE
    nome = VALUES(nome);

COMMIT;

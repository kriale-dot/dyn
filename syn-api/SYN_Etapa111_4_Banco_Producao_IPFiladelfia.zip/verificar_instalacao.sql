USE syn_ipfiladelfia;

SELECT
    (SELECT COUNT(*) FROM papeis) AS papeis,
    (SELECT COUNT(*) FROM usuarios) AS usuarios,
    (SELECT COUNT(*) FROM programacoes) AS programacoes,
    (SELECT COUNT(*) FROM participacoes) AS participacoes,
    (SELECT COUNT(*) FROM igreja) AS igrejas;

SELECT id, codigo, nome
FROM papeis
ORDER BY id;

SELECT id, nome, logotipo
FROM igreja
WHERE singleton = 1;
